﻿using UnityEngine;

public class LevelGenerator : MonoBehaviour {

    public Texture2D top;
    public Texture2D middle;
    public ColorToPrefab[] Colormappings;
    public int TopMiddleBottom;
	// Use this for initialization
	void Start () {
        TopMiddleBottom = 0;
        GenerateLevel();	
	}
    void GenerateLevel() {
        for (int x = 0; x < top.width; x++) {
            for (int y = 0; y < top.height; y++) {
                GenerateTile(x, y);
            }
        }
        TopMiddleBottom = 1;
        for (int x = 0; x < middle.width; x++)
        {
            for (int y = 0; y < middle.height; y++)
            {
                GenerateTile(x, y);
            }
        }
    }
    void GenerateTile(int x, int y) {
        Color pixelColor = top.GetPixel(x,y);
        if (TopMiddleBottom == 0)
        {
             pixelColor = top.GetPixel(x, y);
        }else if (TopMiddleBottom == 1)
        {
            pixelColor = middle.GetPixel(x, y);
        }

        if (pixelColor.a == 0) {
            return;

        }
        foreach (ColorToPrefab colorMapping in Colormappings) {
            if (colorMapping.color.Equals(pixelColor)) {

                Vector3 position = new Vector3(x, TopMiddleBottom, y);
                Instantiate(colorMapping.prefab, position, Quaternion.identity, transform);
            }
        }
        Debug.Log(pixelColor);
    }
}
